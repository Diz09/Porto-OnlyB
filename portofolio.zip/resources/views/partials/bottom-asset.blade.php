<!-- Essential Scripts -->
<script src="{{ asset('plugins/jquery-2.2.4.min.js') }}"></script>
<script src="{{ asset('plugins/bootstrap/bootstrap.min.js') }}"></script>
<script src="{{ asset('plugins/jquery.nicescroll.min.js') }}"></script>
<script src="{{ asset('plugins/isotope/isotope.pkgd.min.js') }}"></script>
<script src="{{ asset('plugins/slick/slick.min.js')}} "></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="{{ asset('js/script.js') }}"></script>
<script src="{{ asset('js/extra.js') }}"></script>